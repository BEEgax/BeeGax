import React, { useState } from "react";
import { TouchableOpacity, View, Text, StyleSheet, Button } from 'react-native';

const HomePage = ({ navigation }) => {
  const [activeTab, setActiveTab] = useState("home");

  const handleTabPress = (tabName) => {
    setActiveTab(tabName);
  };
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Welcome to the Home Page!</Text>
      <Button
        title="Go to Second Page"
        onPress={() => navigation.navigate('Second')}
      />
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.button, activeTab === "hives" && styles.activeButton]}
          // onPress={() => handleTabPress("hives")}
          onPress={() => navigation.navigate('Second')} // working for second page
        ></TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, activeTab === "charts" && styles.activeButton]}
          onPress={() => handleTabPress("charts")}
        ></TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.button,
            activeTab === "locations" && styles.activeButton,
          ]}
          onPress={() => handleTabPress("locations")}
        ></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 24,
    marginBottom: 10,
  },
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5FCFF",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 60,
    backgroundColor: "#FFFFFF",
    shadowOffset: {
      width: 0,
      height: -3,
    },
  },
  button: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#BBBBBB",
    height: "100%",
  },
  activeButton: {
    backgroundColor: "#FFDB58",
  },
  buttonText: {
    fontSize: 16,
    color: "#FFFFFF",
    marginLeft: 5,
  },
  activeButtonText: {
    color: "#FFFFFF",
  },
});

export default HomePage;
